package udesc.pin1.AproveitaEssaJpa2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import udesc.pin1.AproveitaEssaJpa2.controller.AlunoController;
import udesc.pin1.AproveitaEssaJpa2.model.Aluno;
import udesc.pin1.AproveitaEssaJpa2.model.Modulo;

import java.util.Set;

@SpringBootTest
class AproveitaEssaJpa2ApplicationTests {
	/*
	AlunoController alunoController = new AlunoController();



	@Test
	void contextLoads() {

		//Set<Disciplina> disciplinas
		//Set<Modulo> modulos = new
		//Set<Professor> professores

		Aluno aluno = new Aluno(1l,"rafael","45252","adfadfa","senha","47-34525-3424","software",null,null,null);

		aluno.getNome();
		aluno.getCpf();
		aluno.getEmail();
		aluno.getSenha();
		aluno.getTelefone();
		aluno.getNomeCurso();
		aluno.getDisciplinas();
		aluno.getModulos();
		aluno.getProfessores();
		//alunoController.createAluno(aluno);

	}
	*/
}

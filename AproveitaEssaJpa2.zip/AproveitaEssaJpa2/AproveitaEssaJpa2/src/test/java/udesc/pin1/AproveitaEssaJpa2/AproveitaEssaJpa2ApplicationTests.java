package udesc.pin1.AproveitaEssaJpa2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AproveitaEssaJpa2ApplicationTests {

	@Test
	void contextLoads() {
	}

}

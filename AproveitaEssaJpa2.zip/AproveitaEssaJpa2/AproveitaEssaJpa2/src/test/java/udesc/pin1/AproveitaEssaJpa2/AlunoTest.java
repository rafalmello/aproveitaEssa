package udesc.pin1.AproveitaEssaJpa2;

import org.hibernate.mapping.Set;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import udesc.pin1.AproveitaEssaJpa2.Repository.AlunoRepository;
import udesc.pin1.AproveitaEssaJpa2.controller.AlunoController;
import udesc.pin1.AproveitaEssaJpa2.model.Aluno;
import udesc.pin1.AproveitaEssaJpa2.model.Disciplina;
import udesc.pin1.AproveitaEssaJpa2.model.Modulo;
import udesc.pin1.AproveitaEssaJpa2.model.Professor;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;

import static org.mockito.Mockito.when;

//@RunWith(MockitoJUnitRunner.class)
public class AlunoTest {
    /*
    @Mock
    AlunoRepository alunoRepository ;
    AlunoController alunoController = new AlunoController();
    @Test
    public void CriarAluno(){
        LinkedHashSet<Disciplina> setDisciplina = new LinkedHashSet<Disciplina>();
        LinkedHashSet<Professor> setProfessor = new LinkedHashSet<Professor>();
        LinkedHashSet<Modulo> setModulo = new LinkedHashSet<Modulo>();
        Aluno aluno = new Aluno(1l,"rafael","45252","adfadfa","senha","47-34525-3424","software",setDisciplina,setModulo,setProfessor);
        //when(alunoController.createAluno(aluno));
        //when(alunoController.deleteAluno(aluno.getIdUsuario()));
    }

     */
}

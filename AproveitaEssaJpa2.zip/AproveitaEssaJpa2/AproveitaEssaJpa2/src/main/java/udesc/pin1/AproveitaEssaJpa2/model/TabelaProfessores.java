package udesc.pin1.AproveitaEssaJpa2.model;

public class TabelaProfessores {
}

package udesc.pin1.AproveitaEssaJpa2.service;

public class serviceChatAlunoProfessor {
}

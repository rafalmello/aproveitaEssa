package udesc.pin1.AproveitaEssaJpa2.Exception;

public class ExeceptionCriarModulo extends Exception {
    public ExeceptionCriarModulo(String mensagem){
        super(mensagem);

    }
}

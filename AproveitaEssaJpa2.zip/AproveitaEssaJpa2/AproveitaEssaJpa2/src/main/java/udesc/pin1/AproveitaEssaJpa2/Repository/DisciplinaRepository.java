package udesc.pin1.AproveitaEssaJpa2.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import udesc.pin1.AproveitaEssaJpa2.model.Disciplina;

public interface DisciplinaRepository  extends JpaRepository<Disciplina,Long> {
}
